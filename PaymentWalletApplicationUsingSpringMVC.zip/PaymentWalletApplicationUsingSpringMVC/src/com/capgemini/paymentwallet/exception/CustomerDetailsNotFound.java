package com.capgemini.paymentwallet.exception;

public class CustomerDetailsNotFound extends Exception {

	private static final long serialVersionUID = 1L;

	public CustomerDetailsNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerDetailsNotFound(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public CustomerDetailsNotFound(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CustomerDetailsNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CustomerDetailsNotFound(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}



}
